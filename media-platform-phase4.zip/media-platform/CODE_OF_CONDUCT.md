# Code of Conduct

## Our pledge

We as contributors and maintainers pledge to make participation in this
project a harassment-free experience for everyone, regardless of age,
body size, disability, ethnicity, gender identity and expression, level
of experience, nationality, personal appearance, race, religion, or
sexual identity and orientation.

## Our standards

Examples of behavior that contributes to a positive environment:
- Using welcoming and inclusive language
- Being respectful of differing viewpoints and experiences
- Gracefully accepting constructive criticism
- Focusing on what is best for the community

Examples of unacceptable behavior:
- Harassment, insulting/derogatory comments, and personal or political attacks
- Publishing others' private information without explicit permission
- Other conduct which could reasonably be considered inappropriate in a
  professional setting

## Enforcement

Instances of unacceptable behavior may be reported to
{{project.people.maintainer_email}}. All complaints will be reviewed and
investigated promptly and fairly.

This Code of Conduct is adapted from the
[Contributor Covenant](https://www.contributor-covenant.org/), version 2.1.
